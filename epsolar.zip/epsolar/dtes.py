#!/usr/bin/python -u

#--------------------------------------------------------------------------------
# Script for serial communication with EPSolar eTracker
# Author: Dalimil Nejezchleba
# date: 21/04/2020
# Version: 1.0
#---------------------------------------------------------------------------------
softwareVersion = '1.0'

import time # Library to use delays
import sys # system command library
import serial

#config the serial comunication
ser = serial.Serial()
ser.port = "/dev/ttyUSB0"
ser.baudrate = 115200
ser.bytesize = serial.EIGHTBITS #number of bits per bytes
ser.parity = serial.PARITY_NONE #set parity check: no parity
ser.stopbits = serial.STOPBITS_ONE #number of stop bits
ser.timeout = 0.05            #non-block read
ser.xonxoff = False     #disable software flow control
ser.rtscts = False     #disable hardware (RTS/CTS) flow control
ser.dsrdtr = False       #disable hardware (DSR/DTR) flow control
ser.writeTimeout = 0     #timeout for write

try:
          ser.open()
except:
          sys.exit("Port not open")
                        
#main loop
numOfLines = 0 
while True:
                ser.flushInput() #flush input buffer, discarding all its contents
                ser.flushOutput()#flush output buffer, aborting current output                     
                ser.write("01433100001B0AF2".decode("hex"))
                response = str(ser.readline().encode('hex'))
                SolU = float(int( response[14:18],16))/100
                SolI = float(int( response[19:22],16))/100
                print(str(SolI))
                print(str(SolU))
                time.sleep(1)
                numOfLines = numOfLines + 1
                if (numOfLines >= 5):
                  break
              
