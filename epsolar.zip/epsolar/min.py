#!/usr/bin/env python
import minimalmodbus


minimalmodbus.BAUDRATE = 115200

# port name, slave address (in decimal)
instrument = minimalmodbus.Instrument('/dev/ttyUSB0', 1)
    
batVoltage = instrument.read_register(12548, 2,4)
print "BatVolt"
print batVoltage

